pub const NUM_SEAL_WORKERS: usize = 2;

pub const FATAL_NOSEND_TASK: &str = "[run_blocking] could not send";
pub const FATAL_NORECV_TASK: &str = "[run_blocking] could not recv";
